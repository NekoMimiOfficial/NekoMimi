"""
NekoMimi is a python module created by NekoMimi
which aims to make python development easier
and less tiresome

this module contains a variety of functions
and tools that you'd find yourself using a lot 
in most projects, so no more of that copy/paste
action and more coding fluently
"""

__version__ = "1.1.0"
__author__ = "NekoMimi"
__repo__ = "https://github.com/NekoMimiOfficial/NekoMimi.git"
