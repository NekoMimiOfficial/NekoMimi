# NekoMimi Python Module

NekoMimi is my personal python module that I and my friends use to ease up coding  
it aims to get more simple things done without having to write the same code for each project again and again  
I'm trying to add more features that help people and im always on the look for useful shortcuts to be added so if you got any ideas feel free to contact me (links below)  

currently in `alpha phase`


# Installation
```shell
  pip3 install NekoMimi
```

# Importing
```python
  import NekoMimi
```

docs are available [here](https://github.com/NekoMimiOfficial/NekoMimi/blob/main/Docs/README.md)

# Building
```sh
python3 -m build
```
although it's already built in `dist/`

# Twine
```sh
python3 -m twine upload --repository pypi dist/*
```
swap pypi with testpypi for the testing repo

# contact info
Email: nekomimi@tilde.team
Discord : NekoMimi#7225
Reddit: @NekoMimiOfficial
