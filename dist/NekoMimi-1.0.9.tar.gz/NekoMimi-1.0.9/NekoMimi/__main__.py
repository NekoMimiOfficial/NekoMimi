from NekoMimi import tools, colourimi

def _start():
    print(tools.figlet("NekoMimi"))
    print("Python preprocessor")

if __name__ == "__main__":
    _start()
