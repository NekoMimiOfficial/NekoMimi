# NekoMimi Python Module

this is a python package to make your code look nicer and smaller
supports most used modules to make it easy to work with them and to have less of that copy-paste action

currently in `alpha phase`


```shell
  pip3 install NekoMimi
```

to import
```python
  import NekoMimi
```

&nbsp;

docs are available [here](https://github.com/NekoKitsune/NekoMimi/blob/main/Docs/README.md)
